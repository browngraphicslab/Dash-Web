
declare const GoldenLayout: any;
export = GoldenLayout;