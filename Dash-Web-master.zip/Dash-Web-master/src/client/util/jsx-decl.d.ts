declare module 'react-jsx-parser';
