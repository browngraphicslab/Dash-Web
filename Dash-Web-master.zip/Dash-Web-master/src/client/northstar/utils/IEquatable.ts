export interface IEquatable {
    Equals(other: Object): boolean;
}