export interface IDisposable {
    Dispose(): void;
}