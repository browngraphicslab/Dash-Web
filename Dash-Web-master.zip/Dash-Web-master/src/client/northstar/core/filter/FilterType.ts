export enum FilterType
{
    Filter,
    Brush,
    Slice
}