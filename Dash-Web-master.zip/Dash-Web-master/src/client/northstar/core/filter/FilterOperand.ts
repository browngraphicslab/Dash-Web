export enum FilterOperand
{
    AND,
    OR
}