
export const Update = Symbol("Update");
export const Self = Symbol("Self");
export const SelfProxy = Symbol("SelfProxy");
export const HandleUpdate = Symbol("HandleUpdate");
export const Id = Symbol("Id");
export const OnUpdate = Symbol("OnUpdate");
export const Parent = Symbol("Parent");
export const Copy = Symbol("Copy");
export const ToScriptString = Symbol("Copy");